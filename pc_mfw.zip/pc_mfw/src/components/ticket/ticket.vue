<template>
  <div class="ticket">
    <div class="gnjp">
      <div class="flight-icon"></div>
      <span>国内机票</span>
    </div>
    <div class="margin">
      <div class="margin_left">
        <div class="v-com-index-form">
          <div class="choose">
            <ul>
              <li class="current">
                <a href>
                  <span>单程</span>
                </a>
                单程
              </li>
              <li>
                <a href>
                  <span>往返</span>
                </a>往返
              </li>
            </ul>
          </div>
          <div class="form">
            <ul>
              <li>
                <span>出发城市</span>
                <input type="text" placeholder="中文/拼音/简拼" />
              </li>
              <li>
                <span>到达城市</span>
                <input type="text" placeholder="中文/拼音/简拼" />
              </li>
              <li>
                <span>出发日期</span>
                <input type="text" value="2020/07/11" />
              </li>
              <li>
                <span>返回日期</span>
                <input type="text" placeholder="中文/拼音/简拼" />
              </li>
            </ul>
          </div>
          <div class="search">
            <span class="s1">携带儿童（2-12岁）</span>
            <span>
              <img src="../../assets/img/search.png" alt />
              <p>搜索</p>
            </span>
          </div>
        </div>
      </div>
      <div class="margin_right">
        <img src="https://b1-q.mafengwo.net/s15/M00/C4/76/CoUBGV4O9suAX0ViAAHIIQPFJ1s41.jpeg" alt />
      </div>
    </div>
    <div class="margin_end">
      <div class="margin_s1">
        <i></i> 100%航协认证
      </div>
      <div class="margin_s2">
        <i></i>
        出行保证
      </div>
      <div class="margin_s3">
        <i></i>
        <span>7x24小时服务</span>
        <span>4006345678转2</span>
      </div>
    </div>
    <div class="m-title">
      <span class="ticket-icon"></span>
      <span>特价机票</span>
    </div>
    <div class="tjjp">
      <div class="tjjp_item">
        <div class="tjjp_01">
          <img
            src="http://b1-q.mafengwo.net/s5/M00/7B/37/wKgB3FIDDByAcTAFAAPaSajnMyk40.jpeg?imageMogr2%2Fthumbnail%2F%21750x563r%2Fgravity%2FCenter%2Fcrop%2F%21750x563%2Fquality%2F90"
            alt
            height="140"
            width="225"
          />
          <div class="tjjp_01s">
            <span>北京·太原</span>
            <span>￥163</span>
          </div>
        </div>
        <div class="tjjp_02">
          <img
            src="http://b1-q.mafengwo.net/s5/M00/53/D1/wKgB3FGcJuCAFdf1AAM-uEqmHBw07.jpeg?imageMogr2%2Fthumbnail%2F%21750x563r%2Fgravity%2FCenter%2Fcrop%2F%21750x563%2Fquality%2F90"
            alt
            height="140"
            width="225"
          />
          <div class="tjjp_01s">
            <span>北京·大连</span>
            <span>￥304</span>
          </div>
        </div>
        <div class="tjjp_03">
          <img
            src="http://n1-q.mafengwo.net/s7/M00/6D/AD/wKgB6lSzVjSAG6w0AAkhK5yG5RM08.jpeg?imageMogr2%2Fthumbnail%2F%21750x563r%2Fgravity%2FCenter%2Fcrop%2F%21750x563%2Fquality%2F90"
            alt
            height="140"
            width="225"
          />
          <div class="tjjp_01s">
            <span>北京·沈阳</span>
            <span>￥400</span>
          </div>
        </div>
        <div class="tjjp_04">
          <img
            src="http://n1-q.mafengwo.net/s8/M00/7B/EA/wKgBpVW7QnOAeSPvAADFCh-_z1828.jpeg?imageMogr2%2Fthumbnail%2F%21750x563r%2Fgravity%2FCenter%2Fcrop%2F%21750x563%2Fquality%2F90"
            alt
            height="140"
            width="225"
          />
          <div class="tjjp_01s">
            <span>北京·长春</span>
            <span>￥234</span>
          </div>
        </div>
      </div>
      <div class="place-nav">
        <div></div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "ticket"
};
</script>
<style scoped>
.ticket {
  /* border: 1px solid red; */
}
.gnjp {
  width: 110px;
  height: 24px;
  margin-left: 250px;
  margin-top: 10px;
  /* border: 1px solid red; */
}
.gnjp span {
  line-height: 24px;
  font-family: 微软雅黑;
  font-size: 16px;
}
.flight-icon {
  width: 24px;
  height: 24px;
  display: inline-block;
  /* border: 1px solid green; */
  background: url(https://b2-q.mafengwo.net/s14/M00/80/C2/wKgE2l0do-GAczUGAAAaNUcOHfo497.png)
    0 0 no-repeat;
  background-size: auto;
  vertical-align: middle;
  margin-right: 12px;
}
.margin {
  /* border: 1px solid red; */
  height: 350px;
  margin: 20px 250px 20px 250px;
  display: flex;
}
.margin_left {
  flex: 1;
  border: 2px solid orange;
}
.margin_right {
  flex: 2;
  float: right;
  /* border: 2px solid orange; */
  margin-left: 10px;
}
.v-com-index-form {
  margin-bottom: 15px;
  padding: 19px 20px 18px;
  width: 300px;
  height: 310px;
  background: #fff;
  border: 2px solid #ff9d00;
  display: inline-block;
}

.choose ul {
  height: 20px;
  margin-left: 60px;
}
.choose ul li {
  float: left;
  margin-right: 31px;
  line-height: 40px;
  font-size: 18px;
}
.choose ul li a {
  font-size: 10px;
  color: #ffffff;
}
.choose ul li span {
  width: 30px;
  height: 16px;
  display: block;
  background: url(../../assets/img/header-sprites11.png) no-repeat -60px -110px;
}
.choose ul li.current span {
  background-position: -60px -140px;
}
.margin_right img {
  width: 100%;
  height: 100%;
}
.form {
  width: 100%;
  margin-top: 40px;
  height: 200px;
  /* border: 1px solid red; */
}
.form ul {
  display: flex;
  flex-direction: column;
}
.form ul li {
  height: 50px;

  line-height: 45px;
  /* border: 1px solid red; */
  flex: 1;
  font-size: 16px;
}
.form ul li input {
  border: 1px solid #e3e3e3;
  height: 38px;
}
.search {
  /* border: 1px solid red; */
  display: flex;
  flex-direction: column;
}
.search .s1 {
  margin: 0 auto;
}
.search span:nth-child(2) {
  width: 220px;
  height: 30px;
  border: 1px solid red;
  background-color: orange;
  display: flex;
  color: #ffffff;
  font-size: 16px;
  justify-content: center;
  align-items: center;
  margin: 0 auto;
  margin-top: 10px;
}
.search span:nth-child(2) img {
  width: 40px;
  height: 40px;
}
.margin_end {
  height: 58px;
  width: 1000px;
  /* border: 1px solid red; */
  margin: 0 auto;
  background-color: #f6f6f6;
}
.margin_end .margin_s1 {
  display: inline-block;
  padding: 10px 70px;
  width: 300px;
  line-height: 38px;
  position: relative;
}
.margin_end .margin_s1 i {
  display: inline-block;
  background: url(https://b2-q.mafengwo.net/s14/M00/80/C2/wKgE2l0do-GAczUGAAAaNUcOHfo497.png)
    0 -90px no-repeat;
  background-size: auto;
  vertical-align: middle;
  width: 40px;
  height: 34px;
  margin-right: 15px;
}
.margin_end .margin_s2 {
  display: inline-block;
  padding: 10px 0;
  width: 300px;
  line-height: 38px;
  position: relative;
}
.margin_end .margin_s2 i {
  display: inline-block;
  background: url(https://b2-q.mafengwo.net/s14/M00/80/C2/wKgE2l0do-GAczUGAAAaNUcOHfo497.png)
    0 -90px no-repeat;
  background-size: auto;
  background-position: -60px -90px;
  vertical-align: middle;
  width: 34px;
  height: 34px;
  margin-right: 15px;
}
.margin_end .margin_s3 {
  display: inline-block;
  vertical-align: middle;
}
.margin_end .margin_s3 i {
  display: inline-block;
  background: url(https://b2-q.mafengwo.net/s14/M00/80/C2/wKgE2l0do-GAczUGAAAaNUcOHfo497.png)
    0 -90px no-repeat;
  background-position: -120px -90px;
  background-size: auto;
  vertical-align: middle;
  width: 34px;
  height: 34px;
  margin-right: 15px;
}
.margin_end .margin_s3 span:nth-child(3) {
  color: #ff9d00;
}
.m-title {
  /* border: 1px solid red; */
  line-height: 30px;
  font-size: 18px;
  width: 700px;
  margin: 0 auto;
  padding: 10px 150px;
}
.m-title .ticket-icon {
  height: 24px;
  display: inline-block;
  background: url(https://b2-q.mafengwo.net/s14/M00/80/C2/wKgE2l0do-GAczUGAAAaNUcOHfo497.png)
    0 0 no-repeat;
  background-size: auto;
  vertical-align: middle;
  margin-right: 12px;
  width: 26px;
  margin-left: -70px;
  background-position: -30px 0;
}
.tjjp {
  margin: 20px 250px 20px 250px;
}
.tjjp_item {
  display: flex;
}
.tjjp_01s {
  position: absolute;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: space-between;
  margin-top: -20px;
  line-height: 25px;
  color: #fff;
  padding: 0 63px;
  font-size: 14px;
}
.tjjp_01s span {
  color: #ffffff;
}
</style>