<template>
  <div>
    <div class="main">
      <div class="main-in">
        <div class="main-in-top">
          <h4>酒店</h4>
          <div class="sousuo">
            <div class="mudi">
              <input type="text" placeholder="出行目的地" />
            </div>
            <div class="riqi-r">
              <input type="text" placeholder="入住日期" />
              <span></span>
            </div>
            <div class="riqi-l">
              <input type="text" placeholder="入住日期" />
              <span></span>
            </div>
            <div class="sou-d">
              <button></button>
              <span></span>
            </div>
          </div>
          <div class="ggy">
            <ul>
              <li>
                <span></span>
                <div class="zi">
                  <h4>住宿攻略</h4>
                  <p>区域攻略到特色主题，应有尽有</p>
                </div>
              </li>
              <li>
                <span></span>
                <div class="zi">
                  <h4>住宿攻略</h4>
                  <p>区域攻略到特色主题，应有尽有</p>
                </div>
              </li>
              <li>
                <span></span>
                <div class="zi">
                  <h4>住宿攻略</h4>
                  <p>区域攻略到特色主题，应有尽有</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="main-in-bottom">
          <div class="zhuti">
            <h4>主题酒店</h4>
            <div class="x-nav">
              <ul>
                <li class="current">
                  <a href>目的地特色</a>
                </li>
                <li>
                  <a href>血拼购物</a>
                </li>
                <li>
                  <a href>童话小镇</a>
                </li>
                <li>
                  <a href>亲子之选</a>
                </li>
                <li>
                  <a href>迪士尼乐园</a>
                </li>
                <li>
                  <a href>朝拜历史</a>
                </li>
              </ul>
            </div>
            <div style="clear:both;"></div>
            <div class="youtu">
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="zhuti">
            <h4>特价酒店</h4>
            <div class="x-nav">
              <ul>
                <li class="current">
                  <a href>曼谷</a>
                </li>
                <li>
                  <a href>台北</a>
                </li>
                <li>
                  <a href>东京</a>
                </li>
                <li>
                  <a href>香港</a>
                </li>
                <li>
                  <a href>首尔</a>
                </li>
                <li>
                  <a href>新加坡</a>
                </li>
              </ul>
            </div>
            <div style="clear:both;"></div>
            <div class="youtu">
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
              <ul>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
                <li>
                  <div class="nali">
                    <span>奥兰多</span>
                    <span>新西兰</span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style scoped>
.main {
  margin-top: 20px;
}
.main-in {
  width: 1000px;
  margin: 0 auto;
}
.main-in-top h4 {
  width: 1000px;
  height: 110px;
  font-size: 24px;
  line-height: 110px;
}
.sousuo {
  width: 1000px;
  height: 47px;
}
.mudi {
  float: left;
  width: 550px;
  height: 47px;
  border: 1px solid #999999;
  box-sizing: border-box;
}
.mudi input {
  outline: 0;
  border: 0;
  width: 548px;
  height: 45px;
  padding-left: 11px;
  box-sizing: border-box;
  color: #adadad;
}
.riqi-r {
  float: left;
  width: 187px;
  height: 47px;
  border: 1px solid #999999;
  box-sizing: border-box;
  margin-left: 10px;
  position: relative;
}
.riqi-r input {
  outline: 0;
  border: 0;
  width: 185px;
  height: 45px;
  padding-left: 11px;
  box-sizing: border-box;
  color: #adadad;
}
.riqi-r span {
  width: 16px;
  height: 16px;
  display: inline-block;
  background: url(../../assets/img/header-sprites.png) no-repeat 0 -140px;
  position: absolute;
  top: 14px;
  right: 10px;
}
.riqi-l {
  float: left;
  width: 187px;
  height: 47px;
  border: 1px solid #999999;
  box-sizing: border-box;
  margin-left: 10px;
  position: relative;
}
.riqi-l input {
  outline: 0;
  border: 0;
  width: 185px;
  height: 45px;
  padding-left: 11px;
  box-sizing: border-box;
  color: #adadad;
}
.riqi-l span {
  width: 16px;
  height: 16px;
  display: inline-block;
  background: url(../../assets/img/header-sprites.png) no-repeat 0 -140px;
  position: absolute;
  top: 14px;
  right: 10px;
}
.sou-d {
  float: right;
  width: 46px;
  height: 47px;
  margin-left: 10px;
  position: relative;
}
.sou-d button {
  outline: 0;
  border: 0;
  width: 46px;
  height: 47px;
  background: #ff9d00;
}
.sou-d span {
  width: 24px;
  height: 24px;
  display: inline-block;
  background: url(../../assets/img/header-sprites.png) no-repeat 0 -110px;
  position: absolute;
  top: 12px;
  left: 11px;
}
.ggy {
  width: 1000px;
  height: 186px;
  padding: 72px 0;
  box-sizing: border-box;
}
.ggy ul {
  width: 1000px;
}
.ggy ul li {
  float: left;
}
.ggy ul li:nth-of-type(1),
.ggy ul li:nth-of-type(2) {
  width: 373px;
}
.ggy ul li:nth-of-type(2) span {
  width: 42px;
  height: 42px;
  display: block;
  background: url(../../assets/img/hotel-sprites1.png) no-repeat -40px 0;
  margin-right: 13px;
}
.ggy ul li:nth-of-type(3) span {
  width: 43px;
  height: 42px;
  display: block;
  background: url(../../assets/img/hotel-sprites1.png) no-repeat -86px 0;
  margin-right: 13px;
}
.ggy ul li:nth-of-type(3) {
  width: 254px;
}
.ggy ul li span {
  float: left;
  width: 35px;
  height: 42px;
  display: block;
  background: url(../../assets/img/hotel-sprites1.png) no-repeat;
  margin-right: 13px;
}
.zi h4 {
  height: 24px;
  line-height: 24px;
}
.zi p {
  height: 14px;
  line-height: 14px;
}
.zhuti {
  width: 1000px;
  text-align: center;
}
.zhuti h4 {
  height: 80px;
  font-size: 24px;
  line-height: 80px;
}
.x-nav ul {
  width: 1000px;
  height: 53px;
  border-bottom: 1px solid #e4e4e4;
  box-sizing: border-box;
}
.x-nav ul li {
  float: left;
  width: 166px;
  height: 51px;
  line-height: 51px;
}
.x-nav ul li a {
  color: #666;
  font-size: 18px;
}
.current {
  border-bottom: 3px solid #ff8a00;
}
.x-nav ul .current a {
  color: #ff8a00;
}
.youtu {
  height: 503px;
  overflow: hidden;
}
.youtu ul li {
  float: left;
  width: 318px;
  height: 240px;
  background: url(../../assets/img/wKgBs1dL9IuAGK6JAANBrENLW2052.jpeg) no-repeat;
  background-size: 100% 100%;
  float: left;
  margin-top: 19px;
}
.youtu ul:nth-of-type(2) li {
  background: url(../../assets/img/yiyiyi.jpeg) no-repeat;
  background-size: 100% 100%;
}
.youtu ul:nth-of-type(3) li {
  background: url(../../assets/img/wKgBs1dL9IuAV8rXAFrJyv-1p4c46.jpeg) no-repeat;
  background-size: 100% 100%;
}
.youtu ul:nth-of-type(4) li {
  background: url(../../assets/img/wKgBs1dL-H6AOmv4AAIvGmxUHPw48.jpeg) no-repeat;
  background-size: 100% 100%;
}
.youtu ul:nth-of-type(5) li {
  background: url(../../assets/img/wKgBs1dL-H6AdJU1AAT5Wd6Lvds54.jpeg) no-repeat;
  background-size: 100% 100%;
}
.youtu ul:nth-of-type(6) li {
  background: url(../../assets/img/wKgBs1dL9MGAW6v3ABiEmHUWRLU33.jpeg) no-repeat;
  background-size: 100% 100%;
}
.youtu ul li:nth-of-type(2),
.youtu ul li:nth-of-type(3),
.youtu ul li:nth-of-type(5),
.youtu ul li:nth-of-type(6) {
  margin-left: 23px;
}
.nali {
  width: 318px;
  height: 240px;
  background: rgba(0, 0, 0, 0.3);
  font-size: 24px;
  color: #fff;
  font-family: å¾®è½¯é›…é»‘;
  padding-top: 100px;
  text-align: center;
  box-sizing: border-box;
}
.nali span:nth-of-type(1) {
  display: block;
}
.nali span:nth-of-type(2) {
  display: block;
  font-size: 14px;
}
.zhuti:nth-of-type(2) {
  margin-top: 50px;
}
</style>
