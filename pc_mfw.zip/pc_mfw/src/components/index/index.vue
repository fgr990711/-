<template>
  <div>
    <div class="banner clearfix">
      <ul>
        <li>
          <a href>
            <img
              src="https://n1-q.mafengwo.net/s16/M00/43/3B/CoUBUl8B4h2AYCgoABsCBhh_-bg701.png?imageMogr2%2Finterlace%2F1"
              alt
            />
          </a>
          <div class="li-in">
            <a href>
              <p>
                <span>2</span>/Jul.2020
              </p>
              <p>『和你一起走遍全世界 第二站』顺时针自驾土耳其，寻找星月国的浪漫瞬间</p>
            </a>
          </div>
        </li>
      </ul>
      <ol>
        <li class="now">
          <a href>
            <img
              src="https://p1-q.mafengwo.net/s16/M00/43/23/CoUBUl8B4hGAWkIpAASFR2ZK7fY014.png?imageMogr2%2Fthumbnail%2F%21108x67r%2Fgravity%2FCenter%2Fcrop%2F%21108x67%2Fquality%2F90"
              alt
            />
          </a>
        </li>
        <li>
          <a href>
            <img
              src="https://n1-q.mafengwo.net/s16/M00/77/5D/CoUBUl8Ak4aAGpN8AARcw5U_RaA773.png?imageMogr2%2Fthumbnail%2F%21108x67r%2Fgravity%2FCenter%2Fcrop%2F%21108x67%2Fquality%2F90"
              alt
            />
          </a>
        </li>
        <li>
          <a href>
            <img
              src="https://n1-q.mafengwo.net/s16/M00/1D/32/CoUBUl7_S-yAd-TtAASWriPf4lM605.png?imageMogr2%2Fthumbnail%2F%21108x67r%2Fgravity%2FCenter%2Fcrop%2F%21108x67%2Fquality%2F90"
              alt
            />
          </a>
        </li>
        <li>
          <a href>
            <img
              src="https://p1-q.mafengwo.net/s16/M00/F0/E0/CoUBUl78p0uAMhKLAAe3IkQxoaU084.png?imageMogr2%2Fthumbnail%2F%21108x67r%2Fgravity%2FCenter%2Fcrop%2F%21108x67%2Fquality%2F90"
              alt
            />
          </a>
        </li>
        <li>
          <a href>
            <img src="@/assets/img/wKgBs1drjmWAT1fOAAUz9zLUA3Y32.index.w108.jpeg" alt />
          </a>
        </li>
      </ol>
      <!-- 搜索 -->
      <div class="choose">
        <ul>
          <li class="current">
            <a href>
              <span></span>全部
            </a>
          </li>
          <li>
            <a href>
              <span></span>酒店
            </a>
          </li>
          <li>
            <a href>
              <span></span>目的地
            </a>
          </li>
          <li>
            <a href>
              <span></span>商城
            </a>
          </li>
        </ul>
        <div class="sousuo">
          <div class="search">
            <input type="text" placeholder="搜索目的地/攻略/酒店/用户 " />
          </div>
          <button class="fanfdajing">
            <span></span>
          </button>
        </div>
      </div>
      <div class="nav">
        <span>
          <p>
            <strong>自由行</strong>
            旅行就要更自在
          </p>
          <img src="../../assets/img/自由行.png" alt />
        </span>
        <span>
          <p>
            <strong>跟团游</strong>
            行程透明省心游
          </p>
          <img src="../../assets/img/跟团游.png" alt />
        </span>
        <span>
          <p>
            <strong>当地游</strong>
            最地道的玩法体验
          </p>
          <img src="../../assets/img/当地游.png" alt />
        </span>

        <span>
          <p>
            <strong>机票</strong>
            特惠一折起
          </p>
          <img src="../../assets/img/机票03.png" alt />
        </span>
        <span>
          <p>
            <strong>订酒店</strong>
            一键全网比价
          </p>
          <img src="../../assets/img/订酒店01.png" alt />
        </span>
        <span>
          <p>
            <strong>签证</strong>
            出签率高服务佳
          </p>
          <img src="../../assets/img/签证01.png" alt />
        </span>
        <span>
          <p>
            <strong>邮轮</strong>
            移动的海上城堡
          </p>
          <img src="../../assets/img/游轮.png" alt />
        </span>
      </div>
    </div>
    <div style="clear:both"></div>
    <div class="main">
      <div class="main-in">
        <div class="main-top">
          <div class="main-in-left">
            <div class="haihang">
              <a href>
                <img src="@/assets/img/wKgBs1dOvWKAFLsGAACZ1ruM84086.jpeg" alt />
              </a>
            </div>
            <div class="lxjzl">
              <div class="lxjzl-shang">
                <h3>
                  <a href>旅行家专栏</a>
                </h3>
                <span>
                  <a href>专栏首页</a>
                </span>
              </div>
              <div class="lxjzl-zhong">
                <a href>
                  <img src="@/assets/img/wKgBs1dfxxqAFyWVAAE8w-2lOIk79.jpeg" alt />
                </a>
              </div>
              <div class="lxjzl-xia">
                <h4>
                  <a href>芽庄与顺滑隔了多远</a>
                </h4>
                <p>在旅途中，最艰难的莫过于学会告别。因为真的可能，字面上的一眼万年。</p>
              </div>
            </div>
            <div class="lygltj">
              <div class="lygltj-shang">
                <h3>
                  <a href>旅游攻略推荐</a>
                </h3>
                <span>
                  <a href>更多</a>
                </span>
              </div>
              <div class="lygltj-zhong">
                <div class="bldt">
                  <a href>
                    <img src="@/assets/img/wKgBs1dhWoiANjLdAARzAy6P5ok22.jpeg" width="110" alt />
                  </a>
                </div>
                <div class="bldw">
                  <h4>
                    <a href>北领地</a>
                  </h4>
                  <p>详细的吃，住，行，景点，路线，使用信息。</p>
                </div>
              </div>
              <div class="lygltj-xia">
                <ul>
                  <li>
                    <a href>夜雨</a> 点评了 外伶仃岛的
                    <a href>伶仃峰</a>
                  </li>
                  <li>
                    <a href>LORI</a> 点评了 昌平的
                    <a href>北京后花园旅</a>
                  </li>
                  <li>
                    <a href>34744558</a> 点评了 宏村的
                    <a href>弘茗轩茶行</a>
                  </li>
                  <li>
                    <a href>米粥</a> 点评了 青城山的
                    <a href>青城山前山</a>
                  </li>
                  <li>
                    <a href>dandan52</a> 点评了 深圳的
                    <a href>小梅沙</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="shanghai">
              <a href>
                <img src="@/assets/img/wKgBs1dWbECAB47zAAFJICE7nN005.jpeg" alt />
              </a>
            </div>
            <div class="wohd">
              <div class="wohd-shang">
                <h3>
                  <a href>我的活动</a>
                </h3>
                <span>
                  <a href>正在进行</a>
                </span>
              </div>
              <div class="wohd-xia">
                <ul>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href>
                      <span></span>
                      <div class="wohd-xia-w">
                        <h4>卡罗拉双擎，伴你“尽擎”度假</h4>
                        <p>路遇欢喜，约你看大片！</p>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="zxjz">
              <div class="zxjz-shang">
                <h3>
                  <a href>蚂蜂网旅行网站最新进展</a>
                </h3>
              </div>
              <div class="zxjz-xia">
                <ul>
                  <li>
                    06月11日&nbsp;&nbsp;&nbsp;
                    <a href>2016竞猜欧洲杯活动开始</a>
                  </li>
                  <li>
                    05月18日&nbsp;&nbsp;&nbsp;
                    <a href>蚂蜂窝打卡全新升级</a>
                  </li>
                  <li>
                    04月27日&nbsp;&nbsp;&nbsp;
                    <a href>招财猫回归</a>
                  </li>
                  <li>
                    01月23日&nbsp;&nbsp;&nbsp;
                    <a href>时光机带你穿越10年</a>
                  </li>
                  <li>
                    12月29日&nbsp;&nbsp;&nbsp;
                    <a href>中国旅游行业第一部“玩法”诞生</a>
                  </li>
                  <li>
                    01月27日&nbsp;&nbsp;&nbsp;
                    <a href>蚂蜂窝搬入神秘组织办公室</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div class="main-in-right">
            <div class="sanya">
              <a href>
                <img src="@/assets/img/wKgBs1dicXWAJbbuAAF1AeBFGLo22.jpeg" alt />
              </a>
            </div>
            <div class="yiyuan">
              <div class="yiyuan-shang">
                <h3>意愿自由行</h3>
                <span>
                  厦门
                  <i></i>
                  <em>14%</em>
                </span>
              </div>
              <div style="clear:both"></div>
              <div class="yiyuan-xia">
                <div class="yiyuan-xia-zuo">
                  <div id="box">
                    <div class="box-in">
                      <div id="boxin">
                        <div id="left">
                          <ul>
                            <li>
                              <span>蚂蜂窝用户</span>1分钟前 购买了一元自由行
                            </li>
                            <li>
                              <span>蚂蜂窝用户</span>1分钟前 购买了一元自由行
                            </li>
                            <li>
                              <span>蚂蜂窝用户</span>1分钟前 购买了一元自由行
                            </li>
                            <li>
                              <span>蚂蜂窝用户</span>1分钟前 购买了一元自由行
                            </li>
                            <li>
                              <span>蚂蜂窝用户</span>1分钟前 购买了一元自由行
                            </li>
                          </ul>
                        </div>
                        <div id="right"></div>
                      </div>
                    </div>
                  </div>
                  <span class="renshu">
                    <span class="shuzi">
                      3847
                      <span style="font-size:10px;">人</span>
                    </span>
                  </span>
                </div>
                <div class="yiyuan-xia-you">
                  <h3>往返厦门三或四天双人自由行</h3>
                  <span>(首次参与赠50元代金券)</span>
                  <div style="clear:both"></div>
                  <div class="qian">
                    <div class="qian-zuo">
                      <span>
                        <span></span>
                        <span>目标：</span>
                        <span>¥</span>
                        <span>
                          <strong>5000</strong>
                        </span>
                      </span>
                    </div>
                    <div class="qian-you">
                      <a href>
                        <span>一元试试</span>
                      </a>
                    </div>
                  </div>
                  <div style="clear:both"></div>
                  <div class="jdt">
                    <div class="jdt-shang">
                      <span>
                        已支持
                        <em>¥692</em>
                      </span>
                      <span>
                        完成进度
                        <em>14%</em>
                      </span>
                    </div>
                    <div class="jdt-xia">
                      <div class="jdt-xia-in"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div style="clear:both;"></div>
            <div class="xieyouji">
              <div class="xieyouji-top">
                <div class="nav-youji">
                  <ul>
                    <li>
                      <span></span>
                      <a href>姑娘漂亮</a>
                    </li>
                    <li>
                      <a href>带娃去耍</a>
                    </li>
                    <li>
                      <a href>毕业旅行</a>
                    </li>
                  </ul>
                </div>
                <div class="wen">
                  <span></span>
                  <a href>我要上首页</a>
                </div>
                <div class="xie">
                  <a href>
                    <span class="xie-wenzi">
                      <span class="xie-tupian"></span>写游记
                    </span>
                  </a>
                </div>
              </div>
              <div class="xieyouji-main">
                <div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="riji">
                    <div class="riji-zuo"></div>
                    <div class="riji-you">
                      <div class="wenzhang">
                        <dl>
                          <dt>
                            <a href class="enen">花样游记大赛#一路向西去大理（图文并茂，海量照片附视频）</a>
                          </dt>
                          <dd>
                            <a href>
                              是不是对生活不太满意, 很久没有笑过又不知为何？所以，既然不快乐又不喜欢这里, 不如一路向西去大理。我在苍山洱海边，你在哪里？在这一年，我们29岁，孩子3岁。旅行，
                              就是从一个你呆腻了的地方走到别人呆的地方...
                            </a>
                          </dd>
                        </dl>
                      </div>
                      <div class="hudong">
                        <span class="zuobiao">
                          <i></i>
                          <a href>俄罗斯</a>
                        </span>
                        <span class="ren">
                          by
                          <i></i>
                          <span>
                            <a href>橘子大不了</a>
                          </span>
                        </span>
                        <span class="yan">
                          <i></i>6511/113
                        </span>
                        <span class="ding">
                          <i>417</i>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div style="clear:both;"></div>
                <div class="fanye">
                  <div class="yeshu">共50页/600条</div>
                  <div class="yema">
                    <a href class="dqy">1</a>
                    <a href>2</a>
                    <a href>3</a>
                    <a href>4</a>
                    <a href>5</a>
                    <a href>6</a>
                    <a href>7</a>
                    <a href>8</a>
                    <a href>9</a>
                    <a href>下一页>></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*banner*/

.banner {
  height: 500px;
  width: 100%;
  position: relative;
}
.banner ul {
  height: 500px;
  overflow: hidden;
}
.banner ul li {
  height: 500px;
  overflow: hidden;
  position: relative;
}
.banner ul li img {
  width: 100%;
}
.li-in {
  width: 450px;
  height: 86px;
  margin: 0 auto;
  position: absolute;
  top: 0;
  left: 50%;
  margin-left: -450px;
  margin-top: 14px;
}
.li-in p {
  line-height: 36px;
  font-size: 16px;
  color: #ffffff;
  font-weight: bold;
}
.li-in span {
  font-size: 20px;
}
.banner ol {
  position: absolute;
  top: 39px;
  right: 50px;
}
.banner ol li {
  width: 108px;
  height: 67px;
  margin-bottom: 6px;
  cursor: pointer;
}
.banner ol li img {
  width: 100%;
  height: 100%;
}
.now {
  width: 108px;
  height: 67px;
  border: 1px solid #ff9d00;
  box-sizing: border-box;
}
/*search*/
.choose {
  width: 632px;
  height: 109px;
  border-radius: 3px;
  background: #141416;
  opacity: 0.8;
  padding: 8px 15px 15px 15px;
  box-sizing: border-box;
  position: absolute;
  bottom: 44px;
  left: 50%;
  margin-left: -316px;
}
.choose ul {
  height: 40px;
}
.choose ul li {
  float: left;
  margin-right: 31px;
  line-height: 40px;
}
.choose ul li a {
  float: left;
  font-size: 14px;
  color: #ffffff;
}
.choose ul li span {
  float: left;
  width: 16px;
  height: 16px;
  display: block;
  background: url(../../assets/img/header-sprites11.png) no-repeat -60px -110px;
  margin-top: 12px;
  margin-right: 5px;
}
.choose ul li.current span {
  background-position: -60px -140px;
}
.sousuo {
  width: 602px;
  height: 46px;
}
.search {
  float: left;
  width: 542px;
  height: 46px;
  border-radius: 3px;
  background: #ffffff;
}
.search input {
  width: 542px;
  height: 46px;
  border-radius: 3px;
  padding-left: 21px;
  box-sizing: border-box;
  color: #adadad;
}
.fanfdajing {
  float: right;
  width: 50px;
  height: 46px;
  border-radius: 3px;
  border: 0;
  display: block;
  background: #ff9d00;
  position: relative;
}
.fanfdajing span {
  width: 23px;
  height: 24px;
  display: block;
  background: url(../../assets/img/header-sprites11.png) no-repeat 0px -109px;
  position: absolute;
  left: 13px;
  top: 11px;
}
.fanfdajing:hover {
  background: #ff8400;
}
.nav {
  width: 100%;
  height: 60px;
  /* border: 1px solid red; */
  display: flex;
  justify-content: center;
  align-items: center;
}
.nav span {
  border: 1px solid #e3e3e3;
  width: 150px;
  height: 56px;
  display: flex;
}
.nav span img {
  width: 45px;
  height: 45px;
  flex: 1;
}
.nav span p {
  font-size: 12px;
  color: #000;
  display: flex;
  margin-top: 5px;
  flex-direction: column;
  flex: 2;
}
.nav span p strong {
  font-size: 14px;
  font-weight: bolder;
  color: #000;
}

/*main*/
.main {
  margin-top: 20px;
  width: 100%;
}
.main-in {
  width: 1000px;
  margin: 0 auto;
}
/*left*/
.main-in-left {
  float: left;
  width: 260px;
}
.haihang {
  width: 260px;
  height: 260px;
}

.lxjzl {
  width: 260px;
  height: 321px;
}
.lxjzl-shang {
  height: 59px;
  line-height: 59px;
}
.lxjzl-shang h3 {
  float: left;
  font-size: 18px;
  color: #333333;
  font-weight: normal;
}
.lxjzl-shang h3 a:hover {
  color: #333333;
}
.lxjzl-shang span {
  float: right;
  font-size: 12px;
  color: #999999;
}
.lxjzl-shang span a {
  color: #999999;
}
.lxjzl-shang span a:hover {
  color: #999999;
  text-decoration: underline;
}

.lxjzl-xia {
  padding-top: 5px;
}
.lxjzl-xia h4 a {
  font-size: 16px;
  font-weight: normal;
  color: #333333;
  line-height: 36px;
}
.lxjzl-xia h4 a:hover {
  color: #333333;
  text-decoration: underline;
}
.lxjzl-xia p {
  line-height: 20px;
  font-size: 12px;
  color: #666666;
}

.lygltj {
  width: 260px;
  height: 368px;
}
.lygltj-shang {
  width: 260px;
  height: 61px;
}
.lygltj-shang h3 {
  float: left;
  font-size: 18px;
  font-weight: normal;
  color: #333333;
  line-height: 61px;
}
.lygltj-shang h3 a:hover {
  color: #333333;
}
.lygltj-shang span {
  float: right;
  font-size: 12px;
  color: #999999;
  line-height: 61px;
}
.lygltj-shang span a {
  color: #999999;
}
.lygltj-shang span a:hover {
  color: #999999;
  text-decoration: underline;
}
.lygltj-zhong {
  width: 260px;
  height: 167px;
}
.bldt {
  float: left;
}
.bldw {
  float: right;
  width: 129px;
}
.bldw h4 a {
  font-size: 24px;
  color: #333333;
  font-weight: normal;
  line-height: 47px;
}
.bldw h4 a:hover {
  color: #333333;
  text-decoration: underline;
}
.bldw p {
  font-size: 12px;
  font-weight: normal;
  color: #333333;
  line-height: 20px;
}
.lygltj-xia {
  width: 260px;
  height: 140px;
  line-height: 28px;
  font-size: 14px;
}
.lygltj-xia li a {
  color: #ff9d00;
}
.lygltj-xia li a:hover {
  text-decoration: underline;
}

.shanghai {
  margin-top: 30px;
}

.wohd {
  width: 260px;
  margin-top: 13px;
}
.wohd-shang {
  width: 260px;
  height: 69px;
}
.wohd-shang h3 {
  float: left;
  font-size: 18px;
  font-weight: normal;
  color: #333333;
  line-height: 69px;
}
.wohd-shang h3 a:hover {
  color: #333333;
}
.wohd-shang span {
  float: right;
  font-size: 12px;
  color: #999999;
  line-height: 69px;
}
.wohd-shang span a {
  color: #999999;
}
.wohd-shang span a:hover {
  color: #999999;
  text-decoration: underline;
}
.wohd-xia {
  width: 260px;
  padding-left: 5px;
  box-sizing: border-box;
}
.wohd-xia ul {
  width: 270px;
  height: 370px;
  overflow: auto;
}
.wohd-xia ul li {
  height: 40px;
  margin-top: 16px;
  background: #fff;
}
.wohd-xia ul li:hover {
  background: #f8f8f8;
}

.wohd-xia ul li:nth-of-type(1) {
  margin-top: 0;
}
.wohd-xia ul li span {
  float: left;
  width: 40px;
  height: 40px;
  display: block;
  background: url(../../assets/img/wKgBs1dfvyyAJzKqAAAKkK_iG5Y815.png) no-repeat;
}
.wohd-xia-w {
  float: left;
  line-height: 20px;
  margin-left: 8px;
}
.wohd-xia-w h4 {
  font-size: 14px;
  font-weight: normal;
  color: #ff9d00;
}
.wohd-xia-w p {
  font-size: 12px;
  color: #666666;
}

.zxjz {
  margin-top: 37px;
}
.zxjz-shang {
  height: 57px;
  line-height: 57px;
}
.zxjz-shang h3 {
  float: left;
  font-size: 18px;
  font-weight: normal;
  color: #333333;
}
.zxjz-shang h3 a:hover {
  color: #333333;
}
.zxjz-xia ul li {
  height: 30px;
  line-height: 30px;
}
.zxjz-xia ul li a {
  font-size: 12px;
  color: #666666;
}
.zxjz-xia ul li a:hover {
  color: #666666;
  text-decoration: underline;
}
/*right*/
.main-in-right {
  margin-left: -50px;
  float: right;
}

.sanya {
  width: 700px;
  height: 120px;
}

.yiyuan {
  width: 700px;
  height: 235px;
}
.yiyuan-shang {
  height: 54px;
  line-height: 54px;
}
.yiyuan-shang h3 {
  float: left;
  font-size: 18px;
  color: #333333;
  font-weight: normal;
}
.yiyuan-shang span {
  float: right;
  font-size: 18px;
  color: #333333;
  font-weight: normal;
  position: relative;
}
.yiyuan-shang span em {
  font-size: 12px;
}
.yiyuan-shang span i {
  width: 0;
  height: 0;
  border-width: 3px;
  border-color: red transparent transparent transparent;
  border-style: solid dashed dashed dashed;
  overflow: hidden;
  position: absolute;
  top: 39px;
  left: 19px;
}

.yiyuan-xia {
  width: 700px;
  height: 180px;
  border: 1px solid #e9e9e9;
  box-sizing: border-box;
  position: relative;
}
.jiao {
  width: 15px;
  height: 15px;
  border-top: 2px solid #fa635a;
  border-right: 2px solid #fa635a;
  position: absolute;
  top: 0;
  right: 0;
  margin-top: -1px;
  margin-right: -1px;
}
.yiyuan-xia-zuo {
  width: 280px;
  height: 180px;
  background: url(../../assets/img/wKgBs1cxrsiADAFmAO6rVbNx40s17.jpeg);
  background-size: 100% auto;
  position: relative;
  overflow: hidden;
  float: left;
}
.yiyuan-xia-zuo #box {
  width: 280px;
  height: 180px;
  overflow: hidden;
  position: absolute;
  bottom: -134px;
}
.yiyuan-xia-zuo #box .box-in {
  background-color: rgba(0, 0, 0, 0.3);
}
.yiyuan-xia-zuo #box .box-in #boxin {
  height: 500%;
}
.yiyuan-xia-zuo #box .box-in #boxin ul {
  color: #000;
  font-size: 12px;
  color: #fff;
}
.yiyuan-xia-zuo #box .box-in #boxin ul li {
  width: 90%;
  height: 32px;
  line-height: 32px;
  border-top: 1px solid rgba(225, 225, 225, 0.5);
  margin: 0 auto;
}
.yiyuan-xia-you {
  float: right;
  width: 353px;
  height: 178px;
  padding-top: 23px;
  padding-right: 31px;
  box-sizing: border-box;
  text-align: right;
}
.yiyuan-xia-you h3 {
  line-height: 22px;
}
.yiyuan-xia-you span {
  line-height: 41px;
}
.qian {
  float: right;
  width: 276px;
  height: 38px;
  border: 1px solid #fa635a;
  box-sizing: border-box;
  border-radius: 3px;
}
.qian-zuo {
  float: left;
  width: 137px;
  height: 36px;
  line-height: 36px;
  text-align: center;
}
.qian-zuo span {
  height: 36px;
  line-height: 36px;
  display: inline-block;
}
.qian-zuo span span:nth-of-type(1) {
  width: 18px;
  height: 18px;
  display: inline-block;
  background: url(../../assets/img/onebuy2.png) no-repeat 0px -180px;
  vertical-align: bottom;
  margin-bottom: 8px;
  margin-right: 5px;
}
.qian-zuo span span:nth-of-type(2) {
  font-size: 12px;
  color: #909090;
}
.qian-zuo span span:nth-of-type(3) {
  font-size: 12px;
  color: #fa635a;
}
.qian-zuo span span:nth-of-type(4) {
  font-size: 18px;
  color: #fa635a;
  vertical-align: top;
}
.qian-you {
  float: right;
  width: 134px;
  height: 36px;
  bbackground-color: #fa635a;
  text-align: center;
}
.qian-you a {
  width: 134px;
  height: 36px;
  display: block;
}
.qian-you a span {
  font-size: 18px;
  color: #fff;
}
.renshu {
  width: 72px;
  height: 82px;
  background: url(../../assets/img/onebuy2.png) no-repeat -104px -42px;
  display: block;
  position: absolute;
  top: 37px;
  left: 50%;
  margin-left: -36px;
  font-weight: bold;
  font-size: 30px;
  color: #fff;
}
.shuzi {
  display: inline-block;
  text-align: center;
  line-height: 84px;
}
.jdt {
  width: 353px;
  height: 45px;
  margin-top: 9px;
}
.jdt-shang {
  width: 353px;
  height: 29px;
  line-height: 29px;
}
.jdt-shang span:nth-of-type(1) {
  float: left;
  font-size: 14px;
  color: #666666;
}
.jdt-shang span:nth-of-type(2) {
  float: right;
  font-size: 14px;
  color: #666666;
}
.jdt-shang span em {
  color: #ff6155;
  margin-left: 3px;
}
.jdt-xia {
  width: 353px;
  height: 6px;
  border-radius: 3px;
  background-color: #e9e9e9;
}
.jdt-xia-in {
  width: 49px;
  height: 6px;
  border-radius: 3px 0 0 3px;
  background-color: #ff6155;
}
.xieyouji {
  width: 700px;
}
.xieyouji-top {
  width: 700px;
  height: 85px;
  line-height: 85px;
}
.nav-youji {
  float: left;
  height: 85px;
}
.nav-youji ul li {
  float: left;
}
.nav-youji ul li a {
  padding-right: 28px;
  font-size: 16px;
  color: #333333;
}
.nav-youji ul li a:hover {
  color: #333333;
  text-decoration: underline;
}
.nav-youji ul li:nth-of-type(1) a {
  float: right;
  margin-left: 5px;
}
.nav-youji ul li span {
  float: left;
  width: 49px;
  height: 38px;
  display: block;
  background: url(../../assets/img/index-sprites5.png) no-repeat 0px -90px;
  margin-top: 21px;
}

.wen {
  float: left;
}
.wen a {
  float: right;
  color: #ff9d00;
  margin-left: 4px;
}
.wen a:hover {
  text-decoration: underline;
}
.wen span {
  float: left;
  width: 16px;
  height: 16px;
  display: block;
  background: url(../../assets/img/index-sprites5.png) no-repeat -100px -30px;
  margin-top: 34px;
}

.xie {
  float: right;
  width: 140px;
  height: 36px;
  line-height: 36px;
  background: #ff9d00;
  border: none;
  border-radius: 3px;
  margin-top: 22px;
  text-align: center;
}
.xie a {
  width: 140px;
  height: 36px;
  display: block;
}
.xie-wenzi {
  height: 36px;
  display: inline-block;
  font-size: 16px;
  color: #ffffff;
}
.xie-tupian {
  width: 17px;
  height: 16px;
  display: inline-block;
  background: url(../../assets/img/index-sprites5.png) no-repeat 0px -1px;
  margin-right: 7px;
  vertical-align: -3px;
}
.xieyouji-main {
  width: 700px;
}
.riji {
  width: 700px;
  height: 150px;
  padding: 15px 0;
  background-color: #fff;
}
.riji:hover {
  background-color: #f8f8f8;
}
.riji:nth-of-type(1) {
  margin-top: 0;
}
.riji-zuo {
  float: left;
  width: 220px;
  height: 150px;
  background: url(../../assets/img/hah.jpeg) no-repeat;
  background-size: 100% 100%;
}
.riji-you {
  float: right;
  width: 455px;
  height: 150px;
}
.wenzhang {
  width: 455px;
  height: 101px;
}
.riji-you dl dt {
  width: 455px;
  height: 27px;
  line-height: 27px;
}
.riji-you dl dt a {
  width: 420px;
  height: 27px;
  display: block;
  font-size: 20px;
  font-weight: bold;
  color: #333;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.riji-you dl dd {
  width: 455px;
  height: 66px;
  line-height: 22px;
}
.riji-you dl dd a {
  width: 455px;
  height: 66px;
  display: block;
  font-size: 14px;
  color: #666666;
  overflow: hidden;
}

.hudong {
  width: 455px;
  height: 33px;
  line-height: 33px;
  margin-top: 16px;
}
.zuobiao,
.ren {
  float: left;
  color: #666666;
}
.zuobiao i,
.yan i,
.ding {
  display: inline-block;
  background: url(../../assets/img/index-sprites5.png) no-repeat;
}
.zuobiao i {
  width: 14px;
  height: 16px;
  background-position: 0px -50px;
  margin-right: 6px;
  vertical-align: -5px;
}
.zuobiao a {
  color: #666666;
}
.zuobiao a:hover {
  color: #666666;
  text-decoration: underline;
}
.ren i {
  width: 14px;
  height: 16px;
  border-radius: 50%;
  display: inline-block;
  background: url(../../assets/img/wKgBs1da3BCANUSxAAH6xXIZODw12.jpeg) no-repeat;
  margin: 0 5px 0 8px;
  vertical-align: -5px;
}
.ren span a {
  color: #ff9d00;
  margin-right: 13px;
}
.ren span a:hover {
  text-decoration: underline;
}
.yan {
  float: left;
  color: #999999;
  margin-right: 14px;
}
.yan i {
  width: 18px;
  height: 14px;
  background-position: -30px -50px;
  margin: 0 5px 0 8px;
  vertical-align: -5px;
}
.ding i {
  font-style: normal;
  color: #ff9d00;
  margin-left: -24px;
}
.ding {
  float: right;
  width: 37px;
  height: 33px;
  background-position: -60px 0px;
  margin-left: 9px;
}
/*yema*/
.fanye {
  width: 400px;
  height: 24px;
  padding: 36px 0 20px 300px;
}
.yeshu {
  float: left;
  line-height: 24px;
  color: #999999;
}
.yema {
  float: right;
  margin-left: 15px;
  line-height: 24px;
  text-align: center;
}
.yema a {
  float: left;
  width: 21px;
  height: 24px;
  margin-right: 6px;
  color: #666666;
}
.yema a:hover {
  background: #efefef;
  color: #666666;
}
.yema a:nth-of-type(10) {
  width: 63px;
  margin-right: 0;
  background: #ff9d00;
  color: #ffffff;
}
.yema a.dqy {
  background: #ff9d00;
  color: #ffffff;
}
.ggg-in {
  width: 1000px;
  height: 100px;
  margin: 0 auto;
  background: url(../../assets/img/dong.gif) no-repeat;
}
</style>
