<template>
  <div>
    <div class="main">
      <div class="main-in">
        <div class="main-in-top">
          <div class="li-nav">
            <ul class="shu">
              <li>
                <a href>
                  <span></span>请选择您的出发地
                </a>
                <i></i>
              </li>
            </ul>
            <ul class="heng">
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
              <li>
                <span></span>
                <div class="shun">
                  <h3>国内旅游</h3>
                  <div class="heng-a">
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                    <a href>三亚</a>
                  </div>
                </div>
                <i></i>
              </li>
            </ul>
          </div>
          <div class="main-in-top-r">
            <div class="banner">
              <div id="box">
                <div id="boxin">
                  <ul>
                    <li>
                      <img src="../../assets/img/111.png" />
                    </li>
                    <li>
                      <img src="../../assets/img/222.png" />
                    </li>
                    <li>
                      <img src="../../assets/img/333.png" />
                    </li>
                    <li>
                      <img src="../../assets/img/444.png" />
                    </li>
                    <li>
                      <img src="../../assets/img/555.jpeg" />
                    </li>
                    <li>
                      <img src="../../assets/img/111.png" />
                    </li>
                  </ul>
                </div>
                <ol>
                  <li class="current">1999起 海岛任选</li>
                  <li>跟着丁一晨去旅行</li>
                  <li>暑假签证囤起来</li>
                  <li>日本专场特价</li>
                  <li>去海岛爽一下</li>
                </ol>
              </div>
            </div>
            <div class="zhao">
              <div class="zhao-l">
                <a href>马尔代夫</a>
                <a href>海岛旅行</a>
                <a href>半自由行</a>
              </div>
              <div class="zhao-r">
                <input type="text" value="产品名称/目的地/商铺" />
                <div class="sousuo">
                  <button></button>
                  <span></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style="clear:both;"></div>
        <div class="main-in-middle">
          <div style="clear:both;"></div>
          <div class="main-in-middle-yi">
            <div class="tou">
              <h4>
                <a href>本周热销榜&nbsp;</a>
                <span>大家都在买!</span>
              </h4>
              <div class="huan">
                <a href>
                  <span></span>换一换
                </a>
              </div>
            </div>
            <div class="xuanxiang">
              <ul>
                <li>
                  <a href>
                    <div class="tupian">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>美到窒息的海+海岛控的梦想之地·深圳往返大溪地8天6晚自由行</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div class="main-in-middle-yi">
            <div class="tou">
              <h4>
                <a href>休假去哪儿</a>
              </h4>
              <div class="huan">
                <a href>
                  <span></span>换一换
                </a>
              </div>
            </div>
            <div class="xuanxiang">
              <ul>
                <li>
                  <a href>
                    <div class="tupian02">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian02">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian02">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian02">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="main-in-middle-yi">
            <div class="tou">
              <h4>
                <a href>和你去看海</a>
              </h4>
              <div class="huan">
                <a href>
                  <span></span>换一换
                </a>
              </div>
            </div>
            <div class="xuanxiang">
              <ul>
                <li>
                  <a href>
                    <div class="tupian03">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian03">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian03">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
                <li>
                  <a href>
                    <div class="tupian03">
                      <div class="chuntu"></div>
                      <div class="jiaobiao">
                        <span>
                          3
                          <em>折</em>
                        </span>
                        <span></span>
                      </div>
                    </div>
                    <div class="saj">
                      <h4>全国多地至上海迪士尼亲子游（往返机票+迪士尼乐园一日门票)</h4>
                      <span>
                        <strong>￥1729</strong>
                        <i>起</i>
                        <del>￥6590</del>
                      </span>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*main*/
.main {
  margin-top: 16px;
}
.main-in {
  width: 1000px;
  margin: 0 auto;
}
.main-in-top {
  width: 1000px;
  height: 465px;
}
/*ling-nav*/
.li-nav {
  float: left;
  width: 260px;
  height: 465px;
  background: #fff;
  border: 1px solid #dcdcdc;
  box-sizing: border-box;
}
.shu {
  width: 260px;
  height: 46px;
  border: 1px solid #ff9d00;
  box-sizing: border-box;
  margin-top: -1px;
  margin-left: -1px;
  line-height: 46px;
}
.shu li a {
  font-size: 18px;
  font-weight: bold;
}
.shu li a:hover {
  color: #333;
}
.shu li a span {
  width: 10px;
  height: 15px;
  display: inline-block;
  background: url(../../assets/img/index-v4-sprites3.png) -61px -30px no-repeat;
  margin-left: 22px;
  margin-right: 17px;
  vertical-align: middle;
  margin-top: -7px;
}
.shu li i {
  width: 15px;
  height: 9px;
  display: inline-block;
  background: url(../../assets/img/index-v4-sprites3.png) -90px 0 no-repeat;
  float: right;
  margin-top: 18px;
  margin-right: 17px;
}
.heng li {
  width: 238px;
  height: 60px;
  margin: 0 auto;
  border-bottom: 1px dashed #dcdcdc;
  padding-top: 12px;
  box-sizing: border-box;
}
.heng li span {
  float: left;
  width: 24px;
  height: 24px;
  display: inline-block;
  background: url(../../assets/img/index-v4-sprites3.png) no-repeat;
  margin-left: 3px;
  margin-right: 17px;
  vertical-align: middle;
  margin-top: 6px;
}
.shun {
  float: left;
}
.heng li h3 {
  line-height: 18px;
}
.heng-a {
  line-height: 29px;
}
.heng li i {
  float: right;
  width: 8px;
  height: 14px;
  display: inline-block;
  background: url(../../assets/img/index-v4-sprites3.png) no-repeat -30px 0;
  vertical-align: middle;
  margin-top: 10px;
  margin-right: 6px;
}
.heng li:nth-of-type(2) span {
  background-position: 0 -30px;
}
.heng li:nth-of-type(3) span {
  background-position: 0 -60px;
}
.heng li:nth-of-type(4) span {
  background-position: 0 -90px;
}
.heng li:nth-of-type(5) span {
  background-position: 0 -120px;
}
.heng li:nth-of-type(6) span {
  background-position: 0 -150px;
}
/*banner*/
.main-in-top-r {
  float: right;
  width: 730px;
  height: 465px;
}
#box {
  width: 730px;
  height: 405px;
  position: relative;
}
#boxin {
  width: 730px;
  height: 405px;
  overflow: hidden;
  position: relative;
}
#box ul {
  width: 4380px;
  position: absolute;
  top: 0;
  left: 0;
}
#boxin ul li {
  float: left;
}
#box ol {
  position: absolute;
  left: 7px;
  bottom: 10px;
}
#box ol li {
  float: left;
  width: 140px;
  height: 30px;
  background: rgba(255, 255, 255, 0.8);
  line-height: 30px;
  text-align: center;
  margin-right: 4px;
  cursor: pointer;
}
#box ol li.current {
  background: rgba(0, 0, 0, 0.8);
  color: #fff;
}
/*search*/
.zhao {
  width: 730px;
  height: 60px;
  background: #f8f8f8;
  padding: 0 15px;
  box-sizing: border-box;
}
.zhao-l {
  float: left;
  height: 60px;
  line-height: 60px;
}
.zhao-l a {
  margin-right: 23px;
}
.zhao-l a:hover {
  color: #333333;
  text-decoration: underline;
}
.zhao-r {
  float: right;
  width: 421px;
  height: 36px;
  margin-top: 12px;
}
.zhao-r input {
  float: left;
  outline: 0;
  border: 0;
  width: 366px;
  height: 36px;
  border: 1px solid #ff9d00;
  padding-left: 10px;
  box-sizing: border-box;
  color: #adadad;
}
.sousuo {
  float: right;
  width: 55px;
  height: 36px;
  position: relative;
}
.zhao-r button {
  float: right;
  outline: 0;
  border: 0;
  width: 55px;
  height: 36px;
  background: #ff9d00;
}
.sousuo span {
  width: 23px;
  height: 23px;
  display: block;
  background: url(../../assets/img/index-v4-sprites3.png) no-repeat -30px -30px;
  position: absolute;
  top: 7px;
  left: 16px;
}
.main-in-middle {
  width: 1000px;
}
.main-in-middle-yi {
  width: 1000px;
  height: 300px;
  margin-top: 40px;
}
.tou {
  width: 1000px;
  height: 50px;
  border-bottom: 1px solid #f1f1f1;
}
.tou h4 {
  float: left;
  height: 50px;
  line-height: 50px;
}
.tou h4 a {
  font-weight: normal;
  font-family: 微软雅黑;
  font-size: 24px;
  color: #fb6720;
}
.tou h4 span {
  font-size: 14px;
  color: #999;
}
.huan {
  height: 40px;
  float: right;
  line-height: 40px;
  color: #999999;
}
.huan span {
  width: 14px;
  height: 14px;
  background: url(../../assets/img/change.png) no-repeat;
  display: inline-block;
  margin-right: 5px;
  vertical-align: -3px;
}
.huan a {
  color: #999999;
}
.huan a:hover {
  color: #999999;
  text-decoration: underline;
}
.xuanxiang {
  width: 1000px;
  height: 250px;
  margin-top: 15px;
}
.xuanxiang ul li {
  float: left;
  margin-left: 15px;
}
.xuanxiang ul li:nth-of-type(1) {
  margin-left: 0;
}
.xuanxiang ul li:nth-of-type(4) {
  float: right;
}
.tupian {
  width: 238px;
  height: 134px;
  background: url(http://b1-q.mafengwo.net/s8/M00/B9/7C/wKgBpVYKTfCAcBr9AAQx6J5QXsM47.jpeg?imageMogr2%2Fthumbnail%2F%21646x440r%2Fgravity%2FCenter%2Fcrop%2F%21646x440%2Fquality%2F100)
    no-repeat;
  background-size: 100% 100%;
  position: relative;
}
.tupian span:nth-of-type(1) {
  width: 44px;
  height: 20px;
  display: block;
  background: #ff6155;
  text-align: center;
  line-height: 20px;
  margin-left: -4px;
  position: relative;
  z-index: 1;
}
.tupian span:nth-of-type(2) {
  width: 0;
  height: 0;
  display: block;
  border-top: 4px solid transparent;
  border-right: 4px solid #900;
  border-bottom: 4px solid transparent;
  border-left: 4px solid transparent;
  position: absolute;
  top: 16px;
  left: -8px;
}
.saj {
  width: 238px;
  height: 100px;
  border: 1px solid #f1f1f1;
  box-sizing: border-box;
  padding: 0 10px;
  box-sizing: border-box;
}
.saj h4 {
  font-size: 12px;
  color: #000;
  line-height: 21px;
  margin-top: 6px;
}
.saj span {
  line-height: 51px;
  font-size: 22px;
  color: #ff8a00;
}
.saj span i {
  font-style: normal;
  font-size: 14px;
  color: #ff8a00;
}
.saj span del {
  font-size: 14px;
  color: #999999;
}

.tupian02 {
  width: 238px;
  height: 134px;
  background: url(http://n1-q.mafengwo.net/s8/M00/C3/2F/wKgBpVWCVsGALuHDAD6a6QDkLig904.png?imageMogr2%2Fthumbnail%2F%21646x440r%2Fgravity%2FCenter%2Fcrop%2F%21646x440%2Fquality%2F100)
    no-repeat;
  background-size: 100% 100%;
  position: relative;
}
.tupian02 span:nth-of-type(1) {
  width: 44px;
  height: 20px;
  display: block;
  background: #ff6155;
  text-align: center;
  line-height: 20px;
  margin-left: -4px;
  position: relative;
  z-index: 1;
}
.tupian02 span:nth-of-type(2) {
  width: 0;
  height: 0;
  display: block;
  border-top: 4px solid transparent;
  border-right: 4px solid #900;
  border-bottom: 4px solid transparent;
  border-left: 4px solid transparent;
  position: absolute;
  top: 16px;
  left: -8px;
}
.tupian03 {
  width: 238px;
  height: 134px;
  background: url(http://b1-q.mafengwo.net/s9/M00/7F/37/wKgBs1dP15aAEhYRAARtahavugY95.jpeg?imageMogr2%2Fthumbnail%2F%21646x440r%2Fgravity%2FCenter%2Fcrop%2F%21646x440%2Fquality%2F100)
    no-repeat;
  background-size: 100% 100%;
  position: relative;
}
.tupian03 span:nth-of-type(1) {
  width: 44px;
  height: 20px;
  display: block;
  background: #ff6155;
  text-align: center;
  line-height: 20px;
  margin-left: -4px;
  position: relative;
  z-index: 1;
}
.tupian03 span:nth-of-type(2) {
  width: 0;
  height: 0;
  display: block;
  border-top: 4px solid transparent;
  border-right: 4px solid #900;
  border-bottom: 4px solid transparent;
  border-left: 4px solid transparent;
  position: absolute;
  top: 16px;
  left: -8px;
}
</style>
