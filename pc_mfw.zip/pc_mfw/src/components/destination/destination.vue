<template>
  <div>
    <div class="banner">
      <div class="banner-in">
        <div class="pian">
          <div class="pian-n">
            <span>
              <div>DAY</div>
              <div class="four">1</div>
            </span>
            <h4>
              <a href>神仙海岛的三款热门玩法，去普吉一定不能错过</a>
            </h4>
          </div>
          <div style="clear:both;"></div>
          <div class="luxian">
            该线路基于
            关于泰国普吉岛，这个多面风情的岛屿，常年位于境外旅游热搜榜前列，第一次去的人，容易被它的热带海岛风情和高性价比吸引到想再二刷；第N次去的人，更是因为每次都能发现普吉的新玩法，让人想再多宠幸一遍。
          </div>
        </div>
        <div class="search">
          <div class="unkown">Don't fear the unknown</div>
          <div class="go">
            <input type="text" value placeholder="我想去..." />
            <button>
              <span></span>
            </button>
          </div>

          <div class="location">
            <a href>西安</a>
            <a href>澳门</a>
            <a href>苏州</a>
            <a href>南京</a>
            <a href>普吉岛</a>
          </div>
        </div>
      </div>
    </div>
    <div class="main">
      <div class="main-in">
        <div class="main-in-top">
          <div class="main-in-top-in">
            <div class="main-in-er">
              <h3>热门目的地</h3>
              <div class="tjdf-er">
                <ul>
                  <li>
                    <a href>国内</a>
                  </li>
                  <li>
                    <a href>港澳台</a>
                  </li>
                  <li>
                    <a href>日本</a>
                  </li>
                  <li>
                    <a href>东南亚</a>
                  </li>
                  <li class="dangxia-er">
                    <a href>南亚&nbsp;西亚</a>
                  </li>
                  <li>
                    <a href>欧洲&nbsp;美洲</a>
                  </li>
                  <li>
                    <a href>澳洲&nbsp;非洲</a>
                  </li>
                </ul>
              </div>
              <div class="tjwf-er">
                <ul>
                  <li>
                    <div class="sh-y">
                      <div class="riqi">
                        <span>DAY</span>
                        <br />
                        <span>5</span>
                      </div>
                      <h4>厦门鼓浪屿五日玩法</h4>
                    </div>
                  </li>
                  <li>
                    <div class="sz-y">
                      <div class="riqi">
                        <span>DAY</span>
                        <br />
                        <span>5</span>
                      </div>
                      <h4>厦门鼓浪屿五日玩法</h4>
                    </div>
                  </li>
                  <li>
                    <div class="sz-y">
                      <div class="riqi">
                        <span>DAY</span>
                        <br />
                        <span>5</span>
                      </div>
                      <h4>厦门鼓浪屿五日玩法</h4>
                    </div>
                  </li>
                  <li>
                    <div class="sz-y">
                      <div class="riqi">
                        <span>DAY</span>
                        <br />
                        <span>5</span>
                      </div>
                      <h4>厦门鼓浪屿五日玩法</h4>
                    </div>
                  </li>
                  <li>
                    <div class="sz-y">
                      <div class="riqi">
                        <span>DAY</span>
                        <br />
                        <span>5</span>
                      </div>
                      <h4>厦门鼓浪屿五日玩法</h4>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="ztjx"><h3>主题精选</h3></div>
    <div>
      <div class="navlist">
        <ul>
          <li
            class="navli"
            v-for="(item, index) in navList"
            :class="{ activeT: nowIndex === index }"
            @click="tabClick(index)"
            :key="index"
          >
            <i>{{ item.name }}</i>
          </li>
        </ul>
      </div>
      <div class="swiper-container swiper_con">
        <div class="swiper-wrapper">
          <!-- 第一个swiper -->
          <div class="swiper-slide" ref="viewBox">
            <ul>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/01/7A/wKgBs1fH3N6AZNnsAADqLwFUFwk07.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/DD/AC/wKgBs1cYZoSAeI0LACl4YWRp7xA25.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s7/M00/73/95/wKgB6lTfYZWAcmhQAAbZQZnW42s99.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/F8/54/wKgBs1fH0J-Ad7PSAAGpIqB38oU56.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/AF/B7/wKgBs1fFRZCAL651AALKYt-RsZM26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s5/M00/C7/33/wKgB21BJhFGiuRYvABGO4Smh2m475.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/4B/67/wKgBs1fNSD2APdHDAAJp04WM8VE10.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/48/wKgBs1fGTxiAflPPAARWkMLvoJw70.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
          </div>
          <!-- 第二个swiper -->
          <div class="swiper-slide">
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/AF/B7/wKgBs1fFRZCAL651AALKYt-RsZM26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s5/M00/C7/33/wKgB21BJhFGiuRYvABGO4Smh2m475.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/4B/67/wKgBs1fNSD2APdHDAAJp04WM8VE10.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/48/wKgBs1fGTxiAflPPAARWkMLvoJw70.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/AF/B7/wKgBs1fFRZCAL651AALKYt-RsZM26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s5/M00/C7/33/wKgB21BJhFGiuRYvABGO4Smh2m475.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/4B/67/wKgBs1fNSD2APdHDAAJp04WM8VE10.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/48/wKgBs1fGTxiAflPPAARWkMLvoJw70.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
          </div>
          <!-- 第三个swiper -->
          <div class="swiper-slide">
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/48/D2/wKgBs1fGngKAG6UBAAEEsj2OGBs82.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/48/5D/wKgBs1fGndSAISRgAADIBPPAJKs41.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/47/A5/wKgBs1fGnWKAI_5oAAD5M1wEfzc26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/48/18/wKgBs1fGnayAFBpzAADMyWNk4OM00.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/AF/B7/wKgBs1fFRZCAL651AALKYt-RsZM26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s5/M00/C7/33/wKgB21BJhFGiuRYvABGO4Smh2m475.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/4B/67/wKgBs1fNSD2APdHDAAJp04WM8VE10.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/48/wKgBs1fGTxiAflPPAARWkMLvoJw70.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
          </div>
          <!-- 第四个swiper -->
          <div class="swiper-slide">
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/AF/B7/wKgBs1fFRZCAL651AALKYt-RsZM26.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s5/M00/C7/33/wKgB21BJhFGiuRYvABGO4Smh2m475.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/4B/67/wKgBs1fNSD2APdHDAAJp04WM8VE10.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/48/wKgBs1fGTxiAflPPAARWkMLvoJw70.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
            <ul>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/00/47/wKgBs1fH23mAQShsAAE8BocWkuc52.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://n1-q.mafengwo.net/s9/M00/00/AE/wKgBs1fH2_KAVpc8AADIt3T3fcQ27.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://b1-q.mafengwo.net/s9/M00/14/80/wKgBs1fGT1uAYafRAAWB83uVxoo54.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
              <li>
                <img
                  src="http://p1-q.mafengwo.net/s9/M00/4B/EE/wKgBs1fNSXyAXT7MAAFPGRP-9tU50.jpeg?imageMogr2%2Fthumbnail%2F%21476x440r%2Fgravity%2FCenter%2Fcrop%2F%21476x440%2Fquality%2F100"
                  alt=""
                />
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swiper from "swiper";
import "swiper/css/swiper.min.css";
export default {
  name: "swiper",
  data() {
    return {
      navList: [
        { name: "一般一般" },
        { name: "世界第三" },
        { name: "不帅不帅" },
        { name: "美女贼爱" }
      ],
      nowIndex: 0
    };
  },
  components: {},
  mounted() {
    var that = this;
    that.mySwiper = new Swiper(".swiper-container", {
      initialSlide: 0,
      autoplay: false,
      keyboardControl: true,
      autoHeight: true,
      observer: true,
      observeParents: true,
      onSlideChangeStart: function() {
        // console.log(that.mySwiper.activeIndex)
        that.nowIndex = that.mySwiper.activeIndex;
      }
    });
    // this.getList();
  },
  methods: {
    tabClick(index) {
      this.nowIndex = index;
      this.mySwiper.slideTo(index, 1000, false);
    }
  },
  created(id) {}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.ztjx {
  width: 100%;
  display: flex;
  height: 50px;
  /* border: 1px solid red; */
  padding: 10px;
  justify-content: center;
  align-items: center;
}
.ztjx h3 {
  font-size: 25px;
  font-weight: initial;
  margin: 0 auto;
}
.navlist {
  width: 40%;
  height: 40px;
  margin: 20px 470px 20px 470px;
  border-bottom: 1px solid rgba(151, 151, 151, 0.1);
  /* position: relative; */
}
.navli {
  padding: 10px 0px;
  text-align: center;

  float: left;
  margin: 0 1.2rem;
}
.navli i {
  font-style: normal;
  font-size: 16px;
}
.activeT {
  color: #00ba6b;
  padding-bottom: 0.3rem;
  border-bottom: 2px solid #00ba6b;
}
.swiper_con {
  width: 100%;
  margin-bottom: 40px;
  position: relative;
}
.choosegrand {
  position: absolute;
  top: -3;
  right: 0;
}
.show {
  display: block;
}
.none {
  display: none;
}
.swiper-slide ul {
  display: flex;
  padding: 10px 200px;
}
.swiper-slide ul li {
  width: 25%;
  border: 1 px solid red;
}
.swiper-slide ul li img {
  width: 70%;
}
/*banner*/
.banner {
  /* height: 535px;
  width: 1000px; */
  background: url(https://b1-q.mafengwo.net/s15/M00/0F/5F/CoUBGV28HDuALpzxABR490kDN0M39.jpeg);
  background-size: 100% 100%;
}
.banner-in {
  width: 1000px;
  height: 477px;
  margin: 0 auto;
  padding: 110px 12px 23px 0;
  box-sizing: border-box;
  position: relative;
}
.pian {
  float: right;
  text-align: right;
}
.pian-n {
  height: 60px;
  line-height: 60px;
}
.pian-n span {
  width: 60px;
  height: 60px;
  display: inline-block;
  border-radius: 3px;
  background: #fff;
  line-height: 20px;
  text-align: center;
  font-size: 20px;
  color: #666;
  font-weight: bold;
  padding-top: 5px;
  box-sizing: border-box;
}
.four {
  font-size: 34px;
  font-family: 微软雅黑;
  line-height: 30px;
}
.pian-n h4 {
  height: 60px;
  width: 500px;
  overflow: hidden;
  display: inline-block;
  vertical-align: middle;
  margin-top: -46px;
}
.pian-n h4 a {
  font-size: 30px;
  font-weight: bold;
  font-family: 微软雅黑;
  color: #fff;
}
.pian-n h4 a:hover {
  color: #ff9d00;
}
.luxian {
  width: 500px;
  line-height: 40px;
  font-size: 18px;
  color: #fff;
}

/*search*/
.search {
  width: 390px;
  height: 130px;
  border-radius: 4px;
  background: #000;
  opacity: 0.8;
  margin-top: 34px;
  padding-left: 15px;
  box-sizing: border-box;
}
.unkown {
  height: 50px;
  line-height: 50px;
  font-family: "Microsoft Yahei";
  font-size: 20px;
  color: #fff;
}
.go input {
  width: 268px;
  height: 36px;
  border-radius: 4px;
  background-color: #fff;
  font-size: 18px;
  color: #7f7f7f;
  padding-left: 20px;
  box-sizing: border-box;
  outline: 0;
  border: 0;
  vertical-align: middle;
  margin-top: -30px;
}
.go button {
  width: 36px;
  height: 36px;
  background: #ff9d00;
  border: 0;
}
.go button span {
  width: 24px;
  height: 24px;
  display: block;
  background: url(../../assets/img/header-sprites.png) no-repeat 0px -110px;
}
.location a {
  line-height: 46px;
  color: #fff;
}
.location a:hover {
  color: #fff;
  text-decoration: underline;
}

/*main*/
.main {
  padding-top: 20px;
}
/*shang*/
.main-in-top-in {
  width: 1000px;
  margin: 0 auto;
}
.main-in-er {
  width: 1000px;
  margin-top: 61px;
  text-align: center;
}
.main-in-er h3 {
  font-weight: normal;
  line-height: 26px;
  font-family: 微软雅黑;
  font-size: 26px;
  color: #333;
}

.tjdf {
  width: 1000px;
  margin: 0 auto;
}
.tjdf ul {
  height: 53px;
  border-bottom: 1px solid #e4e4e4;
  box-sizing: border-box;
}
.tjdf ul li {
  float: left;
  width: 180px;
  line-height: 52px;
}
.tjdf ul li a {
  font-size: 22px;
  color: #333333;
}
.dangxia {
  border-bottom: 3px solid #ff9d00;
  margin-top: -5px;
}
.tjdf-er {
  width: 1000px;
  margin: 0 auto;
}
.tjdf-er ul {
  height: 60px;
  width: 100%;
  border-bottom: 1px solid #e4e4e4;
  box-sizing: border-box;
}
.tjdf-er ul li {
  float: left;
  width: 110px;
  line-height: 52px;
  border-bottom: #fff solid 3px;
}
.tjdf-er ul li:nth-child(6) {
  margin-left: 50px;
}
.tjdf-er ul li:nth-child(7) {
  margin-left: 50px;
}
.tjdf-er ul li a {
  font-size: 20px;
  color: #333333;
}
.tjdf-er ul li.dangxia-er {
  border-bottom: 3px solid #ff9d00;
}

.tjwf-er {
  width: 1000px;
  margin-top: 29px;
  height: 595px;
  overflow: hidden;
}
.tjwf-er ul li {
  float: left;
}
.tjwf-er {
  width: 1000px;
  margin-top: 29px;
  height: 595px;
  overflow: hidden;
}
.tjwf-er ul li {
  float: left;
}
.tjwf-er ul li:nth-of-type(1) {
  float: left;
  width: 615px;
  height: 290px;
  background: url(../../assets/img/wKgB6lPjXDWALj_xAAHrnf1K_Jk33.jpeg) no-repeat;
  position: relative;
  overflow: hidden;
}
.tjwf-er ul li:nth-of-type(1) .sh-y {
  position: absolute;
  left: 0;
  bottom: -244px;
  width: 615px;
  height: 290px;
  background: rgba(0, 0, 0, 0.3);
  color: #fff;
  text-align: left;
  padding-left: 21px;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(1) .sh-y .riqi {
  float: left;
  width: 46px;
  height: 46px;
  border-right: 2px solid #fff;
  padding: 2px 0;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(1) .sh-y .riqi span:nth-of-type(1) {
  font-size: 14px;
}
.tjwf-er ul li:nth-of-type(1) .sh-y .riqi span:nth-of-type(2) {
  font-size: 34px;
  line-height: 22px;
  font-weight: bold;
}
.tjwf-er ul li:nth-of-type(1) .sh-y h4 {
  float: left;
  margin-left: 8px;
  font-size: 22px;
  font-weight: normal;
  font-family: 微软雅黑;
  line-height: 46px;
}
.tjwf-er ul li:nth-of-type(1) .jt {
  margin-top: 20px;
  font-size: 14px;
  height: 20px;
  line-height: 20px;
}
.tjwf-er ul li:nth-of-type(2) {
  width: 370px;
  height: 290px;
  background: url(../../assets/img/wKgB3FGkNnWAHZ9UAArvBfA7LL895.jpeg) no-repeat;
  position: relative;
  overflow: hidden;
  margin-left: 15px;
}
.tjwf-er ul li:nth-of-type(2) .sz-y {
  width: 370px;
  height: 290px;
  background: rgba(0, 0, 0, 0.3);
  padding-left: 21px;
  box-sizing: border-box;
  color: #fff;
  text-align: left;
  position: absolute;
  left: 0;
  bottom: -244px;
}
.tjwf-er ul li:nth-of-type(2) .sz-y .riqi {
  float: left;
  width: 46px;
  height: 46px;
  border-right: 2px solid #fff;
  padding: 2px 0;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(2) .sz-y .riqi span:nth-of-type(1) {
  font-size: 14px;
}
.tjwf-er ul li:nth-of-type(2) .sz-y .riqi span:nth-of-type(2) {
  font-size: 34px;
  font-weight: bold;
  line-height: 22px;
}
.tjwf-er ul li:nth-of-type(2) .sz-y h4 {
  float: left;
  margin-left: 8px;
  font-size: 22px;
  font-weight: normal;
  font-family: 微软雅黑;
  line-height: 46px;
}
.tjwf-er ul li:nth-of-type(2) .jt {
  margin-top: 20px;
  font-size: 14px;
  height: 20px;
  line-height: 20px;
}
.tjwf-er ul li:nth-of-type(3) {
  width: 300px;
  height: 290px;
  margin-top: 15px;
  background: url(../../assets/img/wKgB6lTV6hqAW5qjAA_WyZ2WId400.jpeg) no-repeat;
  position: relative;
  overflow: hidden;
}
.tjwf-er ul li:nth-of-type(3) .sz-y {
  width: 300px;
  height: 290px;
  background: rgba(0, 0, 0, 0.3);
  padding-left: 21px;
  box-sizing: border-box;
  color: #fff;
  text-align: left;
  position: absolute;
  left: 0;
  bottom: -244px;
}
.tjwf-er ul li:nth-of-type(3) .sz-y .riqi {
  float: left;
  width: 46px;
  height: 46px;
  border-right: 2px solid #fff;
  padding: 2px 0;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(3) .sz-y .riqi span:nth-of-type(1) {
  font-size: 14px;
}
.tjwf-er ul li:nth-of-type(3) .sz-y .riqi span:nth-of-type(2) {
  font-size: 34px;
  font-weight: bold;
  line-height: 22px;
}
.tjwf-er ul li:nth-of-type(3) .sz-y h4 {
  float: left;
  margin-left: 8px;
  font-size: 22px;
  font-weight: normal;
  font-family: 微软雅黑;
  line-height: 46px;
}
.tjwf-er ul li:nth-of-type(3) .jt {
  margin-top: 20px;
  font-size: 14px;
  height: 20px;
  line-height: 20px;
}
.tjwf-er ul li:nth-of-type(4) {
  width: 300px;
  height: 290px;
  margin-left: 15px;
  margin-top: 15px;
  background: url(../../assets/img/wKgB4lNnkPCAX0-3AAI_PDTg8TQ20.jpeg) no-repeat;
  position: relative;
  overflow: hidden;
}
.tjwf-er ul li:nth-of-type(4) .sz-y {
  width: 300px;
  height: 290px;
  background: rgba(0, 0, 0, 0.3);
  padding-left: 21px;
  box-sizing: border-box;
  color: #fff;
  text-align: left;
  position: absolute;
  left: 0;
  bottom: -244px;
}
.tjwf-er ul li:nth-of-type(4) .sz-y .riqi {
  float: left;
  width: 46px;
  height: 46px;
  border-right: 2px solid #fff;
  padding: 2px 0;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(4) .sz-y .riqi span:nth-of-type(1) {
  font-size: 14px;
}
.tjwf-er ul li:nth-of-type(4) .sz-y .riqi span:nth-of-type(2) {
  font-size: 34px;
  font-weight: bold;
  line-height: 22px;
}
.tjwf-er ul li:nth-of-type(4) .sz-y h4 {
  float: left;
  margin-left: 8px;
  font-size: 22px;
  font-weight: normal;
  font-family: 微软雅黑;
  line-height: 46px;
}

.tjwf-er ul li:nth-of-type(5) {
  width: 370px;
  height: 290px;
  margin-left: 15px;
  margin-top: 15px;
  background: url(../../assets/img/wKgBs1bf5XiAGGrKAAVfPe3kaco280.png) no-repeat;
  position: relative;
  overflow: hidden;
}
.tjwf-er ul li:nth-of-type(5) .sz-y {
  width: 370px;
  height: 290px;
  background: rgba(0, 0, 0, 0.3);
  padding-left: 21px;
  box-sizing: border-box;
  color: #fff;
  text-align: left;
  position: absolute;
  left: 0;
  bottom: -244px;
}
.tjwf-er ul li:nth-of-type(5) .sz-y .riqi {
  float: left;
  width: 46px;
  height: 46px;
  border-right: 2px solid #fff;
  padding: 2px 0;
  box-sizing: border-box;
}
.tjwf-er ul li:nth-of-type(5) .sz-y .riqi span:nth-of-type(1) {
  font-size: 14px;
}
.tjwf-er ul li:nth-of-type(5) .sz-y .riqi span:nth-of-type(2) {
  font-size: 34px;
  line-height: 22px;
  font-weight: bold;
}
.tjwf-er ul li:nth-of-type(5) .sz-y h4 {
  float: left;
  margin-left: 8px;
  font-size: 22px;
  font-weight: normal;
  font-family: 微软雅黑;
  line-height: 46px;
}

.main-in-wu {
  margin-top: 15px;
}
/*xia*/
.main-in-buttom {
  background: #fafafa;
  border-top: 1px solid #e4e4e4;
  margin-top: 40px;
  padding-top: 23px;
  padding-bottom: 100px;
  color: #666666;
}
.main-in-buttom-in {
  width: 1000px;
  margin: 0 auto;
}
.main-in-buttom a {
  color: #666666;
}
.main-in-buttom a:hover {
  color: #666666;
  text-decoration: underline;
}
.main-in-buttom span {
  color: #a8a8a8;
}
.main-in-buttom-top h3 {
  font-weight: normal;
  line-height: 63px;
  font-size: 32px;
}
.main-in-buttom-top h3 span {
  font-size: 14px;
  font-family: Arial;
}
.main-in-buttom-top dl {
  width: 1000px;
}
.main-in-buttom-top dl dt {
  height: 52px;
  line-height: 52px;
  font-size: 20px;
}
.main-in-buttom-top dl dd {
  line-height: 30px;
  margin-left: 30px;
}
.main-in-buttom-top dl dd ul li:nth-of-type(1) {
  float: left;
  margin-left: -30px;
  font-family: Centaur, Times New Roman;
  font-weight: bold;
}
.yazhou-all {
  height: 480px;
}
.xuan-zuo {
  float: left;
  width: 333px;
}
.xuan-zhong {
  float: left;
  width: 333px;
}
.xuan-you {
  float: right;
  width: 333px;
}
.quanqiut {
  margin-top: 35px;
}
.bmzhou-all {
  height: 241px;
}
.quanqius,
.quanqiuf,
.quanqiuw {
  margin-top: 35px;
}
.main-in-buttom-buttom {
  width: 1000px;
  background: #fafafa;
  margin: 0 auto;
  margin-top: 40px;
  color: #666666;
}
.main-in-buttom-buttom a {
  color: #666666;
}
.main-in-buttom-buttom a:hover {
  color: #666666;
  text-decoration: underline;
}
.main-in-buttom-buttom h3 {
  font-weight: normal;
  line-height: 63px;
  font-size: 32px;
}
.main-in-buttom-buttom dl dt {
  float: left;
  width: 100px;
  font-size: 22px;
  line-height: 41px;
  display: inline;
}
.main-in-buttom-buttom dl dd {
  line-height: 41px;
  font-size: 14px;
}
.main-in-buttom-buttom dl dd li {
  float: left;
}
.main-in-buttom-buttom dl dd li a {
  padding-right: 83px;
}
.main-in-buttom-buttom dl dd li a span {
  color: #ff3600;
}
.ds {
  width: 1000px;
}
.ai {
  height: 82px;
}
</style>
